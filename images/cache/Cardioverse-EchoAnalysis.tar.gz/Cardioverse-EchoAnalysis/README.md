# Cardioverse-EchoAnalysis
Repository for handling and analyzing Cardioverse VevoLab data

## Requirements:
* numpy >= 2.3.5
* pandas >= 2.3.3

## Instructions:
### Vevo Lab
Place reports exported from the Vevo Lab software in a target directory
run bulk parse vevolab as a module:
~~~
python -m src.vevo_parser.bulk_parse_vevolab <path to directory containing reports> <path to output .csv file>
~~~

#### Optional Parameters:
"--rater" the technition who performed the vevolab analysis, if known.
"--QCer" the technition who QCed the vevolab analysis, if known.
"--correct_hr_csv" path to a .csv containing corrected heartrates if there was an issue with the ECG, to be provided by in-vevo team. 
this will override the heartrate and cardiac output values from the report

#### Expected Output: 
tabular csv containing rows of individual echos sorted by ClimbID, AquisitionDate, and AquisitionTime (in that order of priorety). contains the following columns of measures and metadata from Vevo Lab:
~~~
 ClimbID, VevoLabRater, VevoLabQCer, AcquiredBy, AcquisitionDate, AcquisitionTime, Heart_Rate, LV_Area, LV_Area_Systole, LV_Area_Diastole, LV_Volume, LV_Volume_Systole, LV_Volume_Diastole, LV_SV, LV_EF, LV_CO, BMode_Cycles, LV_DS, LV_DD, LV_FS, LV_Mass, LV_Mass C, LVAW_s, LVAW_d, LVPW_s, LVPW_d.
~~~


### Vevo Strain
Place reports exported from the Vevo Strain software in a target directory
run bulk parse vevolab as a module:
~~~
python -m src.vevo_parser.bulk_parse_vevostrain <path to directory containing reports> <path to output .csv file>
~~~

#### Optional Parameters:
"--rater" the technition who performed the vevolab analysis, if known.
"--QCer" the technition who QCed the vevolab analysis, if known.
"--EchoTech" the technition who performed the echocardiogram, if known.

#### Expected Output: 
tabular csv containing rows of individual echos sorted by ClimbID, AquisitionDate, and AquisitionTime (in that order of priorety). contains the following columns of measures and metadata from Vevo Strain:
~~~
ClimbID, VevoLabRater, VevoLabQCer, AcquiredBy, AcquisitionDate, Heart_Rate, MyoGCS, MyoGLS, EndoGCS, EndoGLS, EF, EDV, ESV, GRS, EdLVmass, EsLVmass, SD-RS-Syst, SD-LS-Syst
~~~
