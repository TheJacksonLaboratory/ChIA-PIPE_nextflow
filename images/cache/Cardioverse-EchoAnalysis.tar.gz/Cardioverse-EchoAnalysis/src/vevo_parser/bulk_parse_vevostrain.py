#from .Utils import parse_vevostrain_output
from .Utils.vevostrain_parser import parse_vevostrain_output
import os
import pandas as pd
import argparse

def bulk_parse_vevostrain(input_dir, output_path,rater="Unknown",QCer="Unknown", EchoTech="Unknown"):
    """
    Parses all VevoStrain output CSV files in the specified directory and saves the combined measurements to a single CSV file.

    Parameters:
    input_dir (str): The directory containing VevoStrain output CSV files.
    output_path (str): The path to save the combined measurements CSV file.
    rater (str, optional): The identifier for the VevoStrain analyst. Defaults to "Unknown".
    QCer (str, optional): The identifier for the person who performed quality control for the rater. Defaults to "Unknown".
    EchoTech (str, optional): The identifier for the person who acquired the echocardiography data. Defaults to "Unknown".
    """
    all_measurements = []
    
    dirs = os.listdir(input_dir)
    for subdir in dirs:
        if os.path.isdir(os.path.join(input_dir, subdir)):
            vevostrain_path = os.path.join(input_dir, subdir,"VevoStrain","PLAX")
            sessions = os.listdir(vevostrain_path)
            for session in sessions:
                if os.path.isdir(os.path.join(vevostrain_path, session)):
                    session_path = os.path.join(vevostrain_path, session)
                    for file in os.listdir(session_path):
                        if file.endswith("Summary(PSLAX).txt"):
                            file_path = os.path.join(session_path, file)
                            measurements_df = parse_vevostrain_output(file_path, rater=rater, QCer=QCer, EchoTech=EchoTech)
                            all_measurements.append(measurements_df)
    
    if all_measurements:
        combined_df = pd.concat(all_measurements, ignore_index=True)
        combined_df.drop_duplicates(subset=["ClimbID", "AcquisitionDate"], inplace=True)
        combined_df.to_csv(output_path, index=False)
        print(f"Combined measurements saved to {output_path}")
    else:
        print("No VevoStrain output CSV files found in the specified directory.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Bulk parse VevoStrain output CSV files.")
    parser.add_argument("input_dir", help="Directory containing VevoStrain output CSV files.")
    parser.add_argument("output_path", help="Path to save the combined measurements CSV file.")
    parser.add_argument("--rater", default="Unknown", help="Identifier for the rater. Defaults to 'Unknown'.")
    parser.add_argument("--QCer", default="Unknown", help="Identifier for the QCer. Defaults to 'Unknown'.")
    parser.add_argument("--EchoTech", default="Unknown", help="Identifier for the person who acquired the echocardiography data. Defaults to 'Unknown'.")
    args = parser.parse_args()
    
    bulk_parse_vevostrain(args.input_dir, args.output_path, rater=args.rater, QCer=args.QCer, EchoTech=args.EchoTech)
