import pandas as pd
import argparse
import numpy as np



def parse_vevolab_output(file_path,rater="Unknown",QCer="Unknown"):
    """
    Parses a VevoLab output CSV file and returns a measuments DataFrame.

    Parameters:
    file_path (str): The path to the VevoLab output CSV file.
    rater (str, optional): The identifier for the VevoLab analyst. Defaults to "Unknown".
    QCer (str, optional): The identifier for the person who performed quality control for the rater. Defaults to "Unknown".
    Returns:
    measurements_df (pd.DataFrame): DataFrame containing measurement data.
    """

    vevolab_to_bioconnect_mapping = {
        "BMode_HeartRate": "Heart_Rate",
        "BMode_Area": "LV_Area",
        "BMode_Area_Systole": "LV_Area_Systole",
        "BMode_Area_Diastole": "LV_Area_Diastole",
        "BMode_Volume": "LV_Volume",
        "BMode_Volume_Systole": "LV_Volume_Systole",
        "BMode_Volume_Diastole": "LV_Volume_Diastole",
        "BMode_StrokeVolume": "LV_SV",
        "BMode_EjectionFraction": "LV_EF",
        "BMode_FractionalShortening": "SKIP",
        "BMode_CardiacOutput": "LV_CO",
        "BMode_Cycles": "BMode_Cycles", # may be useful for QC
        "MMode_HeartRate": "SKIP",
        "MMode_Diameter_Systole": "LV_DS",
        "MMode_Diameter_Diastole": "LV_DD",
        "MMode_Volume_Systole": "SKIP",
        "MMode_Volume_Diastole": "SKIP",
        "MMode_StrokeVolume": "SKIP",
        "MMode_EjectionFraction": "SKIP",
        "MMode_FractionalShortening": "LV_FS",
        "MMode_CardiacOutput": "SKIP",
        "MMode_LVMass": "LV_Mass",
        "MMode_LVMassCor": "LV_Mass C",
        "MMode_LVAW_Systole": "LVAW_s",
        "MMode_LVAW_Diastole": "LVAW_d",
        "MMode_LVPW_Systole": "LVPW_s",
        "MMode_LVPW_Diastole": "LVPW_d"
    }
    
    
    template_dict = {
        'ClimbID': [],
        'VevoLabRater': [],
        'VevoLabQCer': [],
        'AcquiredBy': [],
        'AcquisitionDate': [],
        'AcquisitionTime': [],
        'Heart_Rate': [],
        'LV_Area': [],
        'LV_Area_Systole': [],
        'LV_Area_Diastole': [],
        'LV_Volume': [],
        'LV_Volume_Systole': [],
        'LV_Volume_Diastole': [],
        'LV_SV': [],
        'LV_EF': [],
        'LV_CO': [],
        'BMode_Cycles': [],
        'LV_DS': [],
        'LV_DD': [],
        'LV_FS': [],
        'LV_Mass': [],
        'LV_Mass C': [],
        'LVAW_s': [],
        'LVAW_d': [],
        'LVPW_s': [],
        'LVPW_d': []
    }

    measurements_df = pd.DataFrame.from_dict(template_dict)


    with open(file_path, 'r') as file:
        lines = file.readlines()
    
    data_section=False
    for i, line in enumerate(lines):
        split_line = line.strip().replace('"', '').split(',')
        if not data_section:
            if split_line[0] == 'Series Name':
                data_section = True
                new_row = {}
                new_row['ClimbID'] = split_line[1].split(' ')[0]
                new_row['VevoLabRater'] = rater
                new_row['VevoLabQCer'] = QCer
            else:
                continue
        elif split_line[0] == 'Series Name':
            measurements_df = pd.concat([measurements_df, pd.DataFrame([new_row])], ignore_index=True)
            new_row = {}
            new_row['ClimbID'] = split_line[1].split(' ')[0]
            new_row['VevoLabRater'] = rater
            new_row['VevoLabQCer'] = QCer
        else:
            if split_line[0] == 'Acquired By':
                new_row['AcquiredBy'] = split_line[1]
            elif split_line[0] == 'Series Date':
                new_row['AcquisitionDate'] = split_line[1]
            elif split_line[0] == 'Series Time':
                new_row['AcquisitionTime'] = split_line[1]
            elif len(split_line)>=2:
                if split_line[1].startswith('B-Mode'):
                    if split_line[2]=='Heart Rate':
                        new_row['Heart_Rate'] = float(split_line[4])
                    elif split_line[2]=='Area':
                        new_row['LV_Area'] = float(split_line[4])
                    elif split_line[2]=='Area;s':
                        new_row['LV_Area_Systole'] = float(split_line[4])
                    elif split_line[2]=='Area;d':
                        new_row['LV_Area_Diastole'] = float(split_line[4])
                    elif split_line[2]=='Volume':
                        new_row['LV_Volume'] = float(split_line[4])
                    elif split_line[2]=='Volume;s':
                        new_row['LV_Volume_Systole'] = float(split_line[4])
                    elif split_line[2]=='Volume;d':
                        new_row['LV_Volume_Diastole'] = float(split_line[4])
                    elif split_line[2]=='Stroke Volume':
                        new_row['LV_SV'] = float(split_line[4])
                    elif split_line[2]=='Ejection Fraction':
                        new_row['LV_EF'] = float(split_line[4])
                    elif split_line[2]=='Fractional Shortening':
                        continue #taken from M-Mode
                    elif split_line[2]=='Cardiac Output':
                        new_row['LV_CO'] = float(split_line[4])
                    elif split_line[2]=='Cycles':
                        new_row['BMode_Cycles'] = int(float(split_line[4]))
                elif split_line[1].startswith('M-Mode'):
                    if split_line[2]=='Heart Rate':
                        continue #taken from B-Mode
                    elif split_line[2]=='Diameter;s':
                        new_row['LV_DS'] = float(split_line[4])
                    elif split_line[2]=='Diameter;d':
                        new_row['LV_DD'] = float(split_line[4])
                    elif split_line[2]=='Volume;s':
                        continue #taken from B-Mode
                    elif split_line[2]=='Volume;d':
                        continue #taken from B-Mode
                    elif split_line[2]=='Stroke Volume':
                        continue #taken from B-Mode
                    elif split_line[2]=='Ejection Fraction':
                        continue #new_row['LV_EF'] = float(split_line[4]) #TEST~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    elif split_line[2]=='Fractional Shortening':
                        new_row['LV_FS'] = float(split_line[4])
                    elif split_line[2]=='Cardiac Output':
                        continue #taken from B-Mode
                    elif split_line[2]=='LV Mass':
                        new_row['LV_Mass'] = float(split_line[4])
                    elif split_line[2]=='LV Mass Cor':
                        new_row['LV_Mass C'] = float(split_line[4])
                    elif split_line[2]=='LVAW;s':
                        new_row['LVAW_s'] = float(split_line[4])
                    elif split_line[2]=='LVAW;d':
                        new_row['LVAW_d'] = float(split_line[4])
                    elif split_line[2]=='LVPW;s':
                        new_row['LVPW_s'] = float(split_line[4])
                    elif split_line[2]=='LVPW;d':
                        new_row['LVPW_d'] = float(split_line[4])
    measurements_df = pd.concat([measurements_df, pd.DataFrame([new_row])], ignore_index=True)
    keep_echoes = np.ones(len(measurements_df),dtype=bool)
    for ii in range(len(measurements_df)):
        if all(pd.isna(measurements_df.iloc[ii, 5:])):
            keep_echoes[ii]=False
    measurements_df=measurements_df[keep_echoes].reset_index(drop=True)
    measurements_df.sort_values(by=['ClimbID', 'AcquisitionDate', 'AcquisitionTime'], inplace=True)
    measurements_df.reset_index(drop=True, inplace=True)
    return measurements_df
        
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Parse VevoLab output CSV file.')
    parser.add_argument('file_path', type=str, help='Path to the VevoLab output CSV file.')
    parser.add_argument('out_path', type=str, help='Path to save the parsed measurements CSV file.')
    args = parser.parse_args()

    measurements_df = parse_vevolab_output(args.file_path)
    measurements_df.to_csv(args.out_path, index=False)