import pandas as pd
import argparse
#from Utils.vevolab_parser import parse_vevolab_output
from .vevolab_parser import parse_vevolab_output
import numpy as np

def parse_vevostrain_output(file_path,rater="Unknown",QCer="Unknown",EchoTech="Unknown"):
    """
    Parses a VevoLab output CSV file and returns a measuments DataFrame.

    Parameters:
    file_path (str): The path to the VevoLab output CSV file.
    rater (str, optional): The identifier for the VevoLab analyst. Defaults to "Unknown".
    QCer (str, optional): The identifier for the person who performed quality control for the rater. Defaults to "Unknown".
    EchoTech (str, optional): The identifier for the person who acquired the echocardiography data. Defaults to "Unknown".
    Returns:
    measurements_df (pd.DataFrame): DataFrame containing measurement data.
    """
    if rater is None:
        import os
        rater = os.path.basename(os.path.dirname(file_path))
    
    vevostrain_to_bioconnect_mapping = {
        'Heart Rate': "Heart_Rate",
        "MyoGCS*": "MyoGCS",
        "MyoGLS": "MyoGLS",
        "EndoGCS*": "EndoGCS",
        "EndoGLS": "EndoGLS",
        "EF": "EF",
        "EDV": "EDV",
        "ESV": "ESV",
        "GRS": "GRS",
        "EdLVmass": "EdLVmass",
        "EsLVmass": "EsLVmass",
        "SD-RS-Syst.": "SD-RS-Syst",
        "SD-LS-Syst.": "SD-LS-Syst"
    }
    
    
    template_dict = {
        'ClimbID': [],
        'VevoLabRater': [],
        'VevoLabQCer': [],
        'AcquiredBy': [],
        'AcquisitionDate': [],
        'Heart_Rate': [],
        "MyoGCS": [],
        "MyoGLS": [],
        "EndoGCS": [],
        "EndoGLS": [],
        "EF": [],
        "EDV": [],
        "ESV": [],
        "GRS": [],
        "EdLVmass": [],
        "EsLVmass": [],
        "SD-RS-Syst": [],
        "SD-LS-Syst": []
    }

    measurements_df = pd.Series(template_dict)
    measurements_df["VevoLabRater"] = rater
    measurements_df["VevoLabQCer"] = QCer
    measurements_df["AcquiredBy"] = EchoTech

    strain_df=pd.read_table(file_path,sep="\t",header=None,encoding="iso-8859-1",names=["a","b","c"])
    
    for index, row in strain_df.iterrows():
        if row["a"] == "Series Description":
            measurements_df["ClimbID"] = row["b"].split(" ")[0]
        if row["a"] == "StudyDate":
            measurements_df["AcquisitionDate"] = row["b"]
        if row["a"] in vevostrain_to_bioconnect_mapping.keys():
            measurements_df[vevostrain_to_bioconnect_mapping[row["a"]]] = row["b"]
    measurements_df = measurements_df.to_frame().T
    return measurements_df
        
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Parse VevoStrain output CSV file.')
    parser.add_argument('file_path', type=str, help='Path to the VevoStrain output CSV file.')
    parser.add_argument('out_path', type=str, help='Path to save the parsed measurements CSV file.')
    args = parser.parse_args()

    measurements_df = parse_vevostrain_output(args.file_path)
    measurements_df.to_csv(args.out_path, index=False)
