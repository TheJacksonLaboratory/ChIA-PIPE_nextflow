import pandas as pd
import argparse

def correct_heart_rate(input_df, corrected_hr_csv):
    """
    Corrects heart rate and cardiac output (co) values in the input DataFrame based on a provided CSV file containing corrected heart rates.

    Parameters:
    input_df (pd.DataFrame): The DataFrame containing the original heart rate values to be corrected.
    corrected_hr_csv (str): The path to the CSV file containing the corrected heart rates. The CSV should have columns 'ClimbID', 'AcquisitionDate', and 'Corrected_Heart_Rate'.

    Returns:
    pd.DataFrame: A new DataFrame with corrected heart rate values.
    """

    # Load the corrected heart rates from the CSV file
    corrected_hr_df = pd.read_csv(corrected_hr_csv)
    if corrected_hr_df.columns[2] == "Heart_Rate":
        corrected_hr_df.rename(columns={"Heart_Rate": "Corrected_Heart_Rate"}, inplace=True)
    elif corrected_hr_df.columns[2] != "Corrected_Heart_Rate":
        raise ValueError("The third column in the corrected heart rates CSV must be named 'Corrected_Heart_Rate' or 'Heart_Rate'.")

    # Merge the input DataFrame with the corrected heart rates based on 'ClimbID' and 'AcquisitionDate'
    merged_df = pd.merge(input_df, corrected_hr_df, on=['ClimbID', 'AcquisitionDate'], how='left')

    # Update the 'Heart_Rate' column with the corrected values where available
    merged_df['Heart_Rate'] = merged_df.apply(lambda row: row['Corrected_Heart_Rate'] if not pd.isna(row['Corrected_Heart_Rate']) else row['Heart_Rate'], axis=1)
    # If 'LV_CO' (cardiac output) is present, recalculate it using the corrected heart rate and stroke volume (SV)
    if 'LV_CO' in merged_df.columns and 'SV' in merged_df.columns:
        merged_df['LV_CO'] = merged_df.apply(lambda row: row['SV'] * row['Heart_Rate'] / 1000 if not pd.isna(row['SV']) and not pd.isna(row['Heart_Rate']) else row['LV_CO'], axis=1)  # Assuming SV is in mL and HR in bpm, CO in L/min

    # Drop the 'Corrected_Heart_Rate' column as it's no longer needed
    merged_df.drop(columns=['Corrected_Heart_Rate'], inplace=True)

    return merged_df

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Correct heart rate values in a DataFrame based on a provided CSV file with corrected heart rates.')
    parser.add_argument('input_csv', help='Path to the input CSV file containing the original heart rate values.')
    parser.add_argument('corrected_hr_csv', help='Path to the CSV file containing the corrected heart rates.')
    parser.add_argument('output_csv', help='Path to save the output CSV file with corrected heart rate values.')

    args = parser.parse_args()

    # Load the input DataFrame from the provided CSV file
    input_df = pd.read_csv(args.input_csv)

    # Correct the heart rate values using the provided corrected heart rates CSV
    corrected_df = correct_heart_rate(input_df, args.corrected_hr_csv)

    # Save the corrected DataFrame to a new CSV file
    corrected_df.to_csv(args.output_csv, index=False)
    print(f"Corrected heart rate values saved to {args.output_csv}")
    