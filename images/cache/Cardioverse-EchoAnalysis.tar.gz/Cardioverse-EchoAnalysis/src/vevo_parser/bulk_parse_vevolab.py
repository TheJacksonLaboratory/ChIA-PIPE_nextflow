from .Utils.vevolab_parser import parse_vevolab_output 
from .Utils.heart_rate_correction import correct_heart_rate
import os
import pandas as pd
import argparse

def bulk_parse_vevolab(input_dir, output_path,rater="Unknown",QCer="Unknown", correct_hr_csv=None):
    """
    Parses all VevoLab output CSV files in the specified directory and saves the combined measurements to a single CSV file.

    Parameters:
    input_dir (str): The directory containing VevoLab output CSV files.
    output_path (str): The path to save the combined measurements CSV file.
    rater (str, optional): The identifier for the VevoLab analyst. Defaults to "Unknown".
    QCer (str, optional): The identifier for the person who performed quality control for the rater. Defaults to "Unknown".
    correct_hr_csv (str, optional): The path to the CSV file containing corrected heart rates. If provided, heart rate values will be corrected based on this file.
    """
    all_measurements = []
    
    
    for file in os.listdir(input_dir):
        if file.endswith(".csv"):
            file_path = os.path.join(input_dir, file)
            measurements_df = parse_vevolab_output(file_path, rater=rater, QCer=QCer)
            all_measurements.append(measurements_df)
    
    if all_measurements:
        combined_df = pd.concat(all_measurements, ignore_index=True)
        if correct_hr_csv:
            combined_df = heart_rate_correction.correct_heart_rate(combined_df, correct_hr_csv)
        combined_df.sort_values(by=['ClimbID', 'AcquisitionDate', 'AcquisitionTime'], inplace=True)
        combined_df.reset_index(drop=True, inplace=True)
        combined_df.to_csv(output_path, index=False)
        print(f"Combined measurements saved to {output_path}")
    else:
        print("No VevoLab output CSV files found in the specified directory.")
        combined_df = pd.DataFrame()  # Return an empty DataFrame if no files are found
    return combined_df

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Bulk parse VevoLab output CSV files.")
    parser.add_argument("input_dir", help="Directory containing VevoLab output CSV files.")
    parser.add_argument("output_path", help="Path to save the combined measurements CSV file.")
    parser.add_argument("--rater", default="Unknown", help="Identifier for the rater. Defaults to 'Unknown'.")
    parser.add_argument("--QCer", default="Unknown", help="Identifier for the QCer. Defaults to 'Unknown'.")
    parser.add_argument("--correct_hr_csv", default=None, help="Path to the CSV file containing corrected heart rates. If provided, heart rate values will be corrected based on this file.")
    
    args = parser.parse_args()
    
    bulk_parse_vevolab(args.input_dir, args.output_path, rater=args.rater, QCer=args.QCer, correct_hr_csv=args.correct_hr_csv)