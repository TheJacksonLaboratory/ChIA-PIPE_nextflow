from ..vevo_parser.Utils import vevolab_parser
import pandas as pd

def test_parse_vevolab_output():
    test_file_path = "src/tests/test_Data/VevoLab/test_report_1.csv"
    test_rater = "TestRater"
    test_QCer = "TestQCer"
    expected_output = {
        'ClimbID': ['21991','21992'],
        'VevoLabRater': ['TestRater','TestRater'],
        'VevoLabQCer': ['TestQCer','TestQCer'],
        'AcquiredBy': ["Guest","Guest"],
        'AcquisitionDate': ["2/24/2026","2/24/2026"],
        'AcquisitionTime': ["10:36:09 AM","10:50:59 AM"],
        'Heart_Rate': [517.352878, 590.405904],
        'LV_Area': [19.165031, 17.827666],
        'LV_Area_Systole': [11.985466,10.891996],
        'LV_Area_Diastole': [19.545007,17.969685],
        'LV_Volume': [44.924455, 41.627621],
        'LV_Volume_Systole': [19.643454,17.085742],
        'LV_Volume_Diastole': [46.250779,41.933898],
        'LV_SV': [26.607325, 24.848156],
        'LV_EF': [57.528382, 59.255536],
        'LV_CO': [13.765376, 14.670498],
        'BMode_Cycles': [3.0, 3.0],
        'LV_DS': [2.660459, 2.366761],
        'LV_DD': [3.961272,3.744403],
        'LV_FS': [32.838266, 36.792034],
        'LV_Mass': [77.529255, 150.527311],
        'LV_Mass C': [62.023404, 120.421849],
        'LVAW_s': [1.040993, 1.668949],
        'LVAW_d': [0.620193, 1.137768],
        'LVPW_s': [1.103369, 1.374390],
        'LVPW_d': [0.558400, 0.921172]
    }
    expected_output_df = pd.DataFrame.from_dict(expected_output)
    expected_output_df.sort_values(by=['ClimbID', 'AcquisitionDate', 'AcquisitionTime'], inplace=True)
    expected_output_df.reset_index(drop=True, inplace=True)
    output_df = vevolab_parser.parse_vevolab_output(test_file_path, test_rater, test_QCer)
    pd.testing.assert_frame_equal(output_df, expected_output_df)

