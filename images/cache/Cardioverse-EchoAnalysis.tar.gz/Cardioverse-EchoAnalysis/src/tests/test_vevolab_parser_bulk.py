from ..vevo_parser.bulk_parse_vevolab import bulk_parse_vevolab
import pandas as pd

def test_parse_vevolab_output():
    test_input_dir = "src/tests/test_Data/VevoLab/"
    test_output_path = "src/tests/test_Output/combined_measurements.csv"
    test_rater = "TestRater"
    test_QCer = "TestQCer"
    expected_output = {
        'ClimbID': ['21991','21992','21991','21992'],
        'VevoLabRater': ['TestRater','TestRater','TestRater','TestRater'],
        'VevoLabQCer': ['TestQCer','TestQCer','TestQCer','TestQCer'],
        'AcquiredBy': ["Guest","Guest", "Beth","Beth"],
        'AcquisitionDate': ["2/24/2026","2/24/2026", "2/20/2026","2/20/2026"],
        'AcquisitionTime': ["10:36:09 AM","10:50:59 AM", "7:47:59 AM", "6:39:40 AM"],
        'Heart_Rate': [517.352878, 590.405904, 523.903078, 534.045394],
        'LV_Area': [19.165031, 17.827666, 17.823029, 22.454959],
        'LV_Area_Systole': [11.985466,10.891996, 10.158610, 11.959835],
        'LV_Area_Diastole': [19.545007,17.969685, 17.762228, 21.599851],
        'LV_Volume': [44.924455, 41.627621, 40.030751, 56.506435],
        'LV_Volume_Systole': [19.643454,17.085742, 15.227891, 20.175227],
        'LV_Volume_Diastole': [46.250779,41.933898, 39.523038, 53.041649],
        'LV_SV': [26.607325, 24.848156, 24.295147, 32.866422],
        'LV_EF': [57.528382, 59.255536, 61.470848, 61.963425],
        'LV_CO': [13.765376, 14.670498, 12.728302, 17.552161],
        'BMode_Cycles': [3.0, 3.0, 3.0, 3.0],
        'LV_DS': [2.660459, 2.366761, 1.864273, 2.383501],
        'LV_DD': [3.961272,3.744403, 3.046419, 4.134059],
        'LV_FS': [32.838266, 36.792034, 38.804426, 42.344775],
        'LV_Mass': [77.529255, 150.527311, 130.315283, 104.955592],
        'LV_Mass C': [62.023404, 120.421849, 104.252227, 83.964474],
        'LVAW_s': [1.040993, 1.668949, 1.574725, 1.573778],
        'LVAW_d': [0.620193, 1.137768, 1.263200, 0.753289],
        'LVPW_s': [1.103369, 1.374390, 1.487181, 1.173066],
        'LVPW_d': [0.558400, 0.921172, 1.027524, 0.655847]
    }
    expected_output_df = pd.DataFrame.from_dict(expected_output)
    expected_output_df.sort_values(by=['ClimbID', 'AcquisitionDate', 'AcquisitionTime'], inplace=True)
    expected_output_df.reset_index(drop=True, inplace=True)
    output_df = bulk_parse_vevolab(test_input_dir, test_output_path, test_rater, test_QCer)
    pd.testing.assert_frame_equal(output_df, expected_output_df)

